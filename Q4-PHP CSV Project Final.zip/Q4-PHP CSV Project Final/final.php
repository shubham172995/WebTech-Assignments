<?php
$plainKeywords = explode(',', $_POST['plainText']);
$relevantDocuments = unserialize($_POST['Relevantdocs']);
$docs = unserialize($_POST['docs']);
//echo var_dump($plainKeywords);
//echo var_dump($relevantDocuments);
$fp1 = fopen('NIPS_1987-2015.csv', 'r');
$i=0;
while (!feof($fp1)) {
 	if($i == 0)
 		$keywords = explode(',', fgets($fp1));
 	else
		$docs[$i] = explode(',', fgets($fp1));
	$i++;
}

// 1. Find Keywords pertaining to the particular Document!!
for($j = 1; $j <= count($docs); $j++){
	for($k = 1; $k<=30;$k++)
		{
			if($docs[$j][$k] != 0)
			$docKeyWords[$docs[$j][0]][] = trim($keywords[$k]);
		}
}
echo $plainKeywords[1]."<br>";
echo $docKeyWords[$docs[1][0]][1]."<br>";
echo var_dump($docKeyWords[$docs[1][0]])."<br>";
echo in_array("hi ",$docKeyWords[$docs[1][0]])."<br>";
//$j = $docs[1][0];
//echo $j;

$ptd = 0;
for($j = 1; $j <= count($docs); $j++){
	$f=0;
	for($k = 0; $k<count($plainKeywords);$k++)
		{
		if(!in_array("$plainKeywords[$k]", $docKeyWords[$docs[$j][0]])){
			$f=1;
			break;
		}
		}
		if ($f == 0) {
			$plainTextDocuments[$ptd++] = $docs[$j][0];
		}
}
echo var_dump($plainTextDocuments)."<br>";

echo "Relevant Documents Correct and Incorrect Matches<br>";
echo "Correct Matches: ".count($relevantDocuments)."<br>";
echo "Incorrect Matches: ".(count($docs) - count($relevantDocuments))."<br><br>";

echo "PlainText Documents Correct and Incorrect Matches<br>";
echo "Correct Matches: ".count($plainTextDocuments)."<br>";
echo "Incorrect Matches: ".(count($docs) - count($plainTextDocuments))."<br><br>";

echo "Overall Documents Correct and Incorrect Matches<br>";
$correct = 0;
for($z=0;$z<count($plainTextDocuments);$z++)
	if(in_array($plainTextDocuments[$z], $relevantDocuments))
		$correct++;
	echo "Correct Matches: " .$correct."<br>";
	echo "Incorrect Matches: ".(count($relevantDocuments)-$correct);

?>