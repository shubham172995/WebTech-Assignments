<?php
$fp1 = fopen('NIPS_1987-2015.csv', 'r');
$i=0;
while (!feof($fp1)) {
 	if($i == 0)
 		$keywords = explode(',', fgets($fp1));
 	else
		$docs[$i] = explode(',', fgets($fp1));
	$i++;
}

// 1. Find Keywords pertaining to the particular Document!!
for($j = 1; $j <= count($docs); $j++){
	for($k = 1; $k<=30;$k++)
		{
			if($docs[$j][$k] != 0)
			$docKeyWords[$docs[$j][0]][] = trim($keywords[$k]);
		}
}


// 2.a)Finding the md5 for each keyword
for($j = 1; $j <= count($docs); $j++){
	$keywordIndex = array();
	for($k = 0,$indexIterator = 0; $k<count($docKeyWords[$docs[$j][0]]);$k++,$indexIterator++)
	{
		$processingKeyword = $docKeyWords[$docs[$j][0]][$k];
		$decimal = base_convert(md5($processingKeyword),16,10);
		$num = ltrim(substr($decimal,strlen($decimal)-2),'0');
	
//2.b) Indexing the table key attached in bucket.csv

$fp1 = fopen('bucket.csv', 'r');

	while(!feof($fp1)){
	$s = fgets($fp1);
	$pos = strrpos($s, ';');
	//echo $pos."<br>";
	$st = substr($s, 0,$pos);
	//echo $st."<br>";
	if(!strcmp($st, "\"$num\"")){
		$secretkey = substr($s, $pos+1);
		break;
		}
	}
	fclose($fp1);

//2. c) Calculate SHA-256, SHA-384, SHA-512 for the Keyword!
//echo hash_hmac('ripemd160', 'The quick brown fox jumped over the lazy dog.', 'secret');
	//$s1 = hash('sha256', $secretkey);
	//$s2 = hash('sha384', $secretkey);
	//$s3 = hash('sha512', $secretkey);


	$s1 = hash_hmac('sha256', $processingKeyword, $secretkey);
	$s2 = hash_hmac('sha384', $processingKeyword, $secretkey);
	$s3 = hash_hmac('sha512', $processingKeyword, $secretkey);


	//Working Till Above

// 2. d) Generate a string of length 2688 bits 
	$fullString = $s2.$s1.$s3.$s2.$s1.$s3.$s2;
	$shaString = "";
	for($i=0; $i<strlen($fullString);$i++){
	  	switch($fullString[$i])
	    {
	      case 0:
	      $shaString .= "0000";
	      break;
	      case 1:
	      $shaString .= "0001";
	      break;
	      case 2:
	      $shaString .= "0010";
	      break;
	      case 3:
	      $shaString .= "0011";
	      break;
	      case 4:
	      $shaString .= "0100";
	      break;
	      case 5:
	      $shaString .= "0101";
	      break;
	      case 6:
	      $shaString .= "0110";
	      break;
	      case 7:
	      $shaString .= "0111";
	      break;
	      case 8:
	      $shaString .= "1000";
	      break;
	      case 9:
	      $shaString .= "1001";
	      break;
	      case 'a':
	      $shaString .= "1010";
	      break;
	      case 'b':
	      $shaString .= "1011";
	      break;
	      case 'c':
	      $shaString .= "1100";
	      break;
	      case 'd':
	      $shaString .= "1101";
	      break;
	      case 'e':
	      $shaString .= "1110";
	      break;
	      case 'f':
	      $shaString .= "1111";
	      break;
	      default:
	      $shaString .="Not Hex";
	      break;
	   }
	}
// 2.e)Split the string into sub-strings of length d(6)
	//Substrings = 2688/6 = 448 strings
	$strLength = strlen($shaString)/6;
	for($p=0;$p<$strLength;$p++){
		//for($q=6*$p;$q<(6*$p)+6;$q++)
			//$substrings[$p][] = $shaString[$q];
		$substrings[$p] = substr($shaString,$p*6,6);
	}
	//2. f) If all the bits in the substrings are 0, Replace the substring with a single bit 0 else replace with 1.
                   
	for($m=0;$m<$strLength;$m++){
		$f=0;
		for($n=0; $n<6;$n++){
			if($substrings[$m][$n]!=0)
			{
				$f=1;
				break;
			}
		}
		if($f)
		$substrings[$m] = 1;
		else
		$substrings[$m] = 0; 	
	}
	//echo "Checking For KEYWORD INDEX <br><br>";
//2. g) Generate the output String of length 448 bits
	for($z=0;$z<$strLength;$z++)
	$keywordIndex[$indexIterator] .= $substrings[$z];
	//echo ($keywordIndex[$indexIterator])."<br>";
}
// 3.Generate a Bitwise-And for all the keyword indexes
		$finalIndex = substr($keywordIndex[0], 0);
		for($s=0;$s<count($keywordIndex);$s++)
			$finalIndex = $finalIndex & $keywordIndex[$s]; 
		$documentName = $docs[$j][0];

// 4. Store the Index of all documents in Database

$conn = mysqli_connect('localhost','root','test','apoorv');
$query = "insert into Documents values ('".$documentName."','".$finalIndex."')";

if ($conn->query($query) === TRUE) {
  //  echo "<center><b>New record created successfully<b><center>";
} else {
	echo "Error: " . $sql . "<br>" . $conn->error;
}
}

	echo "Enter comma separated Strings to Search(Note: MaxLength=5)!!<br>";
//5. Read search term from the user. Generate the query string
?>
	<form name="Form1" action="process.php" method="post">
		<input type="text" name="Keywords"><br>
		<input type="hidden" name="docs" value="<?php echo htmlentities(serialize($docs)) ?>">
		<input type="submit" name="submit" value="Click to Check the Results">
	</form>
