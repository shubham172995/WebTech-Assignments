<!DOCTYPE HTML>
<html>
<head>
	<title>
		A2Q1_1
	</title>
</head>
<body><hr>
	<p style="background-color: orange;">
		Here, you will upload a file. You need to enter the format of the permissible file and the restriction on the size of the file to be uploaded.
	</p>
	<hr>
	<form action="A2Q1_2.php" method="POST" enctype="multipart/form-data">
		Type: <input type="text" name="type">
		Size: <input type="text" name="size">
		File: <input type="file" name="file" id="file"><br/>
		<input type="submit">
	</form>
</body>
</html>