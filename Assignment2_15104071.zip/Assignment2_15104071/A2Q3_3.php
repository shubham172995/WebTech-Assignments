<?php
session_start();
$_SESSION['First'] = $_POST['First'];
$_SESSION['Last'] = $_POST['Last'];
$_SESSION['Gender'] = $_POST['Gender'];
$_SESSION['Caste'] = $_POST['Caste'];
$_SESSION['DOB'] = $_POST['DOB'];
$_SESSION['Qualification'] = $_POST['Qualification'];
$_SESSION['Address'] = $_POST['Address'];
$_SESSION['Email'] = $_POST['Email'];
$_SESSION['Contact'] = $_POST['Contact'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Form Validation</title>
</head>
<body>
	<div class="container">
		<h1 class="text-center">Just a minute. We would verify the details you entered.</h1>
		<div class="alert" id="msg"></div>
		<form id="regForm" action="process.php" method="post">
		  <div class="form-group">
		    <label>First Name</label>
		    <input type="text" class="form-control" id="name" name="First" readonly value=<?php echo $_SESSION['First']; ?>>
		  </div>
		  <div class="form-group">
		    <label>Last Name</label>
		    <input type="text" class="form-control" id="name" name="Last" readonly value=<?php echo $_SESSION['Last']; ?>>
		  </div>
		  
		  <div class="form-group">
		    <label>Gender</label>
		    <input type="text" class="form-control" id="name" name="Gender" readonly value=<?php echo $_SESSION['Gender']; ?>>
		  </div>
		  
		  <div class="form-group">
		    <label>Caste</label>
		    <input type="text" class="form-control" id="name" name="Caste" readonly value=<?php echo $_SESSION['Caste']; ?>>
		  </div>
		  <div class="form-group">
		    <label>Date of Birth</label>
		    <input type="text" class="form-control" id="name" readonly name="DOB" value=<?php echo $_SESSION['DOB']?>>
		    <input type="hidden" name="key" value="2">
		  </div>
		   <div class="form-group">
		    <input type="hidden" class="form-control" id="name" name="name" value="1">
		  </div>
		  <div class="form-group">
		    <label>Qualification</label>
		    <input type="text" class="form-control" id="email" readonly name="Qualification" value=<?php echo $_SESSION['Qualification'] ?>>
		  </div>
		  <div class="form-group">
		    <label>Address</label>
		    <input type="text" class="form-control" id="Address" readonly name="Address" value=<?php echo $_SESSION['Address']?>>
		  </div>
		  <div class="form-group">
		    <label>Email</label>
		    <input type="text" class="form-control" id="Email" readonly name="Email" value=<?php echo $_SESSION['Email']?>>

		    <label>Contact Number</label>
		    <input type="text" class="form-control" id="Contact" readonly name="Contact" value=<?php echo $_SESSION['Contact'] ?>>
		  </div>
		  <button type="submit" formaction="Reg2.php" class="btn btn-default">Edit</button>
		  <button type="submit" class="btn btn-default">Submit</button>
		</form>
	</div>
</body>
</html>