<?php

session_start();

?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Form Validation</title>
</head>
<body>
	<div class="container">
		<h1 class="text-center">Register here.</h1>
		<div class="alert" id="msg"></div>
		<form id="regForm" action="Reg2.php" method="post">
		  <div class="form-group">
		    <label>Username</label>
		    <input type="text" required class="form-control" id="name" name="name">
		    <input type="hidden" class="form-control" id="name" name="key" value="1">
		  </div>
		  <div class="form-group">
		    <label>Password</label>
		    <input type="text" required class="form-control" id="email" name="password">
		  </div>
		  <button type="submit" class="btn btn-default">Submit</button>
		</form>
	</div>
</body>
</html>