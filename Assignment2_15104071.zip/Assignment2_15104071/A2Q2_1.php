<!DOCTYPE HTML>
<html>
<head>
	<title>
		A2Q1_1
	</title>
</head>
<body><hr>
	<p style="background-color: #574126;">
		Here, you will upload a file. If the directory on the server contains a file with the same name, number will be appended to it.
	</p>
	<hr>
	<form action="A2Q2_2.php" method="POST" enctype="multipart/form-data">
		File: <input type="file" name="file" id="file"><br/>
		<input type="submit">
	</form>
</body>
</html>