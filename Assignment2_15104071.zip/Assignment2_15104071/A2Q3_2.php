<?php
	session_start();
	$name = $_POST['name'];
	$password = $_POST['password'];
	
	if($_SESSION['name'] == $name && $_POST['key'] == 1)
	{
	echo "<center><b>There's already a username you have entered. Try a different username.<b><center>";
	} else{
	$_SESSION['name'] = $name;
	$_SESSION['password'] = $password;	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Validation of form data.</title>
</head>
<body>
	<div class="container">
		<h1 class="text-center">Registration form for you, Hi! Job Seeker.</h1>
		<div class="alert" id="msg"></div>
		<form id="regForm" action="details.php" method="post">
		  <div class="form-group">
		    <label>First Name*</label>
		    <input type="text" class="form-control" id="name" name="First" required value=<?php echo $_SESSION['First']; ?>>
		  </div>
		  <div class="form-group">
		    <label>Last Name</label>
		    <input type="text" class="form-control" id="name" name="Last" value=<?php echo $_SESSION['Last']; ?>>
		  </div>
		  
		  <div class="form-group">
		    <label>Gender</label>
		    <input type="text" class="form-control" id="name" name="Gender" value=<?php echo $_SESSION['Gender']; ?>>
		  </div>
		  
		  <div class="form-group">
		    <label>Caste* (Just for the records. Nothing personal)</label>
		    <input type="text" class="form-control" id="name" name="Caste" required value=<?php echo $_SESSION['Caste']; ?>>
		  </div>
		  
		  <div class="form-group">
		    <label>We send Birthday Cards and we certainly don't judge by age. Date of Birth, please?</label>
		    <input type="text" class="form-control" id="name" name="DOB" value=<?php echo $_SESSION['DOB']; ?>>
		  </div>
		  <div class="form-group">
		    <label>Qualification</label>
		    <input type="text" class="form-control" id="email" name="Qualification" value=<?php echo $_SESSION['Qualification'] ?>>
		  </div>
		  <div class="form-group">
		    <label>Sometimes, we send letters. An address for the postcard, please?</label>
		    <input type="text" class="form-control" id="password" name="Address" value=<?php echo $_SESSION['Address']?>>
		  </div>
		  <div class="form-group">
		    <label>Maybe, we'd like to send an E-letter someday. E-mail address, please?</label>
		    <input type="text" class="form-control" id="password2" name="Email" value=<?php echo $_SESSION['Email']?>>
		    <label>We'd like to get in touch. Mind sharing phone number?</label>
		    <input type="text" class="form-control" id="password2" name="Contact" value=<?php echo $_SESSION['Contact']?>>
		  </div>
		  <button type="submit" class="btn btn-default">Submit</button>
		</form>
	</div>
</body>
</html>
<?php
}
?>