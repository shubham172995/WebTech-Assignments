<?php
session_start();

// Collecting all the details of the User
$first_name = $_SESSION['First']; 
$last_name = $_SESSION['Last']; 
$gender = $_SESSION['Gender']; 
$caste = $_SESSION['Caste']; 
$DOB = $_SESSION['DOB'];
$Qualification = $_SESSION['Qualification'];
$Address = $_SESSION['Address']; 
$Email = $_SESSION['Email'];
$Contact = $_SESSION['Contact']; 
$conn = mysqli_connect('localhost','root','apoorv','apoorv');

//$check = "select * from form where name = '".$name."'";
//$result = $conn->query($check);
// if ($result->num_rows > 0) {
// echo "Username already exists,Please Enter a New Username!!";
// } else {

// Storing infomation in the Database
$query = "insert into Job_Registration values ('".$first_name."','".$last_name."','".$gender."','".$caste."','".$DOB."','".$Qualification."','".$Address."','".$Email."','".$Contact."')";

if ($conn->query($query) === TRUE) {
    echo "<center><b>New record created successfully<b><center>";
} else {
echo "Error: " . $sql . "<br>" . $conn->error;
}

?>