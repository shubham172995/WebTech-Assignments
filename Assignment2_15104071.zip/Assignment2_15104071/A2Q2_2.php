<!DOCTYPE HTML>
<html>
<head>
	<title>
		A2Q1_2
	</title>
</head>
<body>
	<hr>
	<?php
	$name=basename($_FILES["file"]["name"]);
	$dir='/home/Desktop/';
	$files=scandir($dir);
	$i=0;
	foreach($files as $key=>$value){
	if($value==$name)
	$i=$key;
}
	++$i;
	$temp=49;
	$name.=chr($temp);
	++$temp;
	echo $name;
	while($files[$i]==$name){
	$len=strlen($name);
	$name=substr($name, 0, $len-1);
	$name=$name.chr($temp);
	++$temp;
	++$i;
}
$target_Path = $dir.basename( $_FILES['file']['name'] );
move_uploaded_file( $_FILES['file']['tmp_name'], $target_Path );
echo "File saved with name $name";
?>
</body>
</html>
