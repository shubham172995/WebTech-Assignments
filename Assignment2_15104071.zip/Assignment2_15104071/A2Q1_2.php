<<!DOCTYPE HTML>
<html>
<head>
	<title>
		A2Q1_2
	</title>
</head>
<body>
	<?php
	$size=$_POST["size"];
	$type=$_POST["type"];
	$temp=$_FILES["file"]["size"];
	$t=$_FILES["file"]["type"];	
	if($temp > $size){
		echo "File too large";
	}
	else if($t!=$type)
		echo "File incompatible";
	else{
		move_uploaded_file($_FILES["file"]["temp_name"], "/home/Desktop".$_FILES["file"]["name"]);
		echo "File successfully saved at '/home/Desktop'";
	}
	?>
</body>
</html>
