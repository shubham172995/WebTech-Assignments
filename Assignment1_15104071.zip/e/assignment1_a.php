<!DOCTYPE HTML>
<html>
<head>
	<title>
		Assignment 1_a
	</title>
</head>
<body style="background-color:#000000;">
	<p style="color:#ffffff;">
	Here goes the video.<br>
	<p style="color: red;">
		If your browser does not support video tag, text will be displayed that reads <b> <em>"Your browser does not support video tag."</em></b>.
	</p>
</p>
	<?php
	if(isset($_POST["video"])){?>
		<p align="center">
		<video width=<?php echo $_POST["width"]; ?> height= <?php echo $_POST["height"]; ?> controls>
		<source src=<?php echo $_POST["video"]; ?> type="video/mp4" > 
			Your browser does not support video tag.<br>
		</video></p>
	<?php } ?>
</body>
</html>
