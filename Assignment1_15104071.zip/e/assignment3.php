<!DOCTYPE HTML>
<html>
<head>
	<title>
		Assignment-1 Q.3
	</title>
</head>
<body>
	<?php
	if(isset($_POST["first"])&&isset($_POST["second"])){
		$str1=$_POST["first"];
		$str2=$_POST["second"];
		$len1=strlen($str1);
		$len2=strlen($str2);
		$x=0;
		if($len1==$len2){
		for($i=0;$i < $len1;$i++){
		$c1=ord($str1{$i});
		$c2=ord($str2{$i});
		$x=$x+$c1-$c2;
	}
	if($x==0)
	echo "Anagrams";
	else echo"Not Anagrams";}
	else echo "Not Anagrams";
	}
	?>
</body>
</html>