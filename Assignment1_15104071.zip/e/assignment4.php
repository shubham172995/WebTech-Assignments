<!doctype html>
<html>
<head>
<title>Sum of Numbers</title>
</head>
<body>
<?php
$totalSum=0;
if ($_POST['submit']) 
{
if($_POST['num'])
{
   $numbers=explode(',',$_POST['num']);
   foreach ($numbers as $num) {
   	$m=$num;
   	while($num!=1){
   		if($num==0)break;
   		if($num%2!=0)break;
   		$num=$num/2;
   	}
   	if($num==1)$totalSum=$totalSum+$m;
   }
   echo "Total Sum of Numbers which are power of 2 is $totalSum";
}else
{
echo "Numbers not entered";
}
}else
{
	echo "Input N numbers and you will get the sum of the numbers which are a power of 2";
}
?>
<form  action="assignment4.php" method=“post”>
<label for="name">Enter the numbers separated by comma</label>
<input name="num" type="text" />
<br>
<input type="submit" name="submit" value="submit"/>
</form>
</body>
</html>