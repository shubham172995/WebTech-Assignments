<!DOCTYPE HTML>
<html>
<head>
	<title>
		Assignment 2_a
	</title>
</head>
<body style="background-color:#ffffff;">
	<p style="color:#000000;">
	Here goes the audio.<br>
	<p style="color: red;">
		If your browser does not support audio tag, text will be displayed that reads <b> <em>"Your browser does not support audio tag."</em></b>.
	</p>
</p>
	<?php
	if(isset($_POST["audio"])){?>
		<p align="center">
		<audio controls>
		<source src= <?php echo $_POST["audio"]; ?> type=<?php echo"audio/".$_POST["type"]; ?> 
			Your browser does not support audio tag.<br>
		</video></p>
	<?php } ?>
</body>
</html>
